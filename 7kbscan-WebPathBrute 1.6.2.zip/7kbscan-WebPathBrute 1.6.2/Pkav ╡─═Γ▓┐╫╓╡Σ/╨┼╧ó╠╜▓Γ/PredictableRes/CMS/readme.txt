# some files generated with cms-explorer
http://code.google.com/p/cms-explorer/
use these for q&d but cms explorer does a lot more

# wordpress.fuzz.txt generating by cat >>, sort, uniq of multiple versions of wordpress for wordpress into one fuzzfile, for maximum detection in full effect, yo 
