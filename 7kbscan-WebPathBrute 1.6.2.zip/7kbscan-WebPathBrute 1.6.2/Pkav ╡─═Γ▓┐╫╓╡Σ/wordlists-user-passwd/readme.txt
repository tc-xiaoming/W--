
various notes

leetspeak filter 
cat plain.wordlist | sed -e 's/a/4/g' -e 's/e/3/g' -e 's/i/1/g' -e 's/o/0/g' -e 's/s/5/g' -e 's/t/7/g' > l337.wordlist

more wordlists
ftp://ftp.ox.ac.uk/pub/wordlists/
http://theargon.com/achilles/wordlists/
http://www.totse.com/en/hack/word_lists/index.html
http://www.outpost9.com/files/WordLists.html
http://packetstormsecurity.org/Crackers/wordlists/

passwd brute force tools

cupp - passwd profiler
http://www.remote-exploit.org/?page_id=506

awlg - associative wordlist generator
http://awlg.org/index.gen

thc-hydra
http://freeworld.thc.org/thc-hydra/

cain & abel
http://www.oxid.it/cain.html

jtr
http://www.openwall.com/john/

lcp - free l0phtcrack replacement
http://www.lcpsoft.com/english/download.htm


